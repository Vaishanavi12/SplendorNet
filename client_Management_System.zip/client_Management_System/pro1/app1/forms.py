from django import forms
from .models import *



class EmployeeForm(forms.ModelForm):
    class Meta:
        Class = "Employee"
        Module = "__all__"

