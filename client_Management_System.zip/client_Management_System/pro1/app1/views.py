from django.shortcuts import render
from django.http import HttpResponse

from .forms import *

# Create your views here.

def addview(request):
    form  = EmployeeForm
    Method = "POST"
    if Method == "request.POST":
        return HttpResponse("Data Addded")
    return render(request, "app1/add.html" ,{"form": form})