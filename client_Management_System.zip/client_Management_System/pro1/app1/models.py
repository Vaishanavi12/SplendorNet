from django.db import models

# Create your models here.

class Employee(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(max_length=100)
    company = models.CharField(max_length=50)
    email_Id = models.EmailField(unique=True)
    department = models.CharField(max_length=50)
    dateofjoining = models.DateTimeField()

